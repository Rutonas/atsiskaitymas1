# Sukurkite filmų klasę "Movie", kuri:
# * Turės klasės lygio 'docstring' tipo komentarą, trumpai aprašantį, kas tai
#   per klasė.
# * Turės 'docstring' tipo komentarą prie kiekvieno metodo, trumpai aprašantį,
#   ką tas metodas atlieka.
# * Gebės sukurti objektus su 3 savybėmis ir 1 metodu.

# Naudojant šią klasę sukurkite bent du skirtingus filmų objektus.

# Savybės:
# * title (str)
# * director (str)
# * budget (int)

# Metodas:
# * was_expensive() - jeigu filmo "budget" yra daugiau nei 100 mln. USD,
#   grąžins True, kitu atveju - False.

class Movie:
    def __init__(self, title, director, budget):
        self.title = title
        self.director =director
        self.budget = budget

    def was_expensive(self):
        return self.budget > 100000000

filmas1 = Movie('Shrek 2', 'DreamWorks', 436471.036)
filmas2 = Movie('The Incredibles', 'Buena Vista/Pixar', 251657.0042)
filmas3 = Movie('Toy Story 2', 'Buena Vista',  1243567982.50)
print(filmas1.was_expensive())
print(filmas2.was_expensive())
print(filmas3.was_expensive())


