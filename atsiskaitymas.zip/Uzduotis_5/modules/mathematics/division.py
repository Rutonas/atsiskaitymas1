"""Perform division operation."""

def divide(a, b):
  """Divide two numbers."""
  return a / b
