"""Perform addition operation."""

def add(a, b):
  """Add two numbers."""
  return a + b
