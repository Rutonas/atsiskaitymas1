"""Perform subtraction operation."""

def subtract(a, b):
  """Subtract two numbers."""
  return a - b
