"""Perform multiplication operation."""

def multiply(a, b):
  """Multiply two numbers."""
  return a * b
